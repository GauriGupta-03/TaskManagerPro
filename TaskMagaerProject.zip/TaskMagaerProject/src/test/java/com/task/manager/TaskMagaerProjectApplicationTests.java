package com.task.manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskMagaerProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
