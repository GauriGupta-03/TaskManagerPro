package com.task.manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskMagaerProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskMagaerProjectApplication.class, args);
	}

}
